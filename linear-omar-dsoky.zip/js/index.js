// https://templated.co/linear
// HTML & CSS Only